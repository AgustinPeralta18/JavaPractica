
package tp1_ejercicio1;


import java.util.Scanner;

public class TP1_EJERCICIO1 {


    public static void main(String[] args) {
        float num1= 0, num2 = 0, resultado;
        int opcion;
        Calculadora myCalculadora = new Calculadora(num1, num2);
        Scanner reader = new Scanner(System.in);
        System.out.println("BIENVENIDO");
        System.out.println("Ingrese una opcion");
        System.out.println("SUMA [1]");
        System.out.println("RESTA [2]");
        System.out.println("MULTIPLICACION [3]");
        System.out.println("DIVISION [4]");
        opcion = reader.nextInt();

        System.out.println("Ingrese el primer numero");
        num1 = reader.nextFloat();
        System.out.println("Ingrese el segundo numero");
        num2 = reader.nextFloat();


        switch (opcion){
            case 1:
                myCalculadora.suma(num1,num2);
                break;
            case 2:
                myCalculadora.resta(num1,num2);
                break;
            case 3:
                myCalculadora.multiplicacion(num1,num2);
                break;
            case 4:
                myCalculadora.division(num1,num2);
                break;
            default:
                break;

        }




        
        
        

    }
    
}
