
package tp1_ejercicio1;


public class Calculadora {
    private float num1;
    private float num2;


    public Calculadora(float num1, float num2){
        this.num1 = num1;
        this.num2 = num2;
    }
    
    public float suma(float num1, float num2){
        return(num1 + num2);
    }
    
    public float resta(float num1, float num2){
        return(num1 - num2);
    }
    
    public float multiplicacion(float num1, float num2){
        return(num1 * num2);
    }
    
    public float division(float num1, float num2){
        return(num1 / num2);
    }
    
}

