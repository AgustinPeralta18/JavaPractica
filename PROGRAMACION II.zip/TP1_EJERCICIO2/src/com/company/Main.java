package com.company;


public class Main {

    public static void main(String[] args) {
	    Autos myAuto = new Autos();

	    myAuto.ingreso();
	    myAuto.acelerar(0,0);
		myAuto.comparacion();

    }
}
