package com.company;

import java.util.Scanner;
import java.util.ArrayList;
public class Main {

    public static void main(String[] args) {
        ArrayList <Estudiante> estudiantes = new ArrayList<>();
        ArrayList <Profesores> profesores = new ArrayList<>();
        ArrayList <Personal> personalServicio = new ArrayList<>();
        Estudiante myStudent = new Estudiante("a","b","c",0,0,0);
        Profesores myTeacher = new Profesores("a","b","c",0,"d");
        Personal myAssist = new Personal("a","b","c",0,"d");
        Scanner read = new Scanner(System.in);
        int opcion;
        do {


            System.out.println("USTED QUE ES?");
            System.out.println("Estudiante [1]");
            System.out.println("Profesor [2]");
            System.out.println("Personal de servicio [3]");
            System.out.println("Salir [4]");
            opcion = read.nextInt();



            switch (opcion){
                case 1:
                    myStudent.ingresarNombre();
                    myStudent.ingresarApellido();
                    myStudent.ingresarDni();
                    myStudent.ingresarEstadoCivil();
                    myStudent.incorporacion();
                    myStudent.despacho();
                    myStudent.ingresoCurso();
                    estudiantes.add(myStudent);
                    break;
                case 2:
                    myTeacher.ingresarNombre();
                    myTeacher.ingresarApellido();
                    myTeacher.ingresarDni();
                    myTeacher.ingresarEstadoCivil();
                    myTeacher.determinado();
                    profesores.add(myTeacher);
                    break;
                case 3:
                    myAssist.ingreseSeccion();
                    personalServicio.add(myAssist);
                default:
                    System.out.println("Se equivoco de numero");
                    break;
            }
        }while (opcion != 4);
















        myStudent.incorporacion();








    }
}
