package com.company;

public class Main {

    public static void main(String[] args) {

            Triangulo myTriangulo = new Triangulo(0,0,0,0,0);

            myTriangulo.ingresarTriangulo();
            myTriangulo.comparacion();
            myTriangulo.perimetro();
    }
}
